using System;

namespace OperatorAssignment
{
    // Define the Employee class
    public class Employee
    {
        // Properties for Employee ID, FirstName, and LastName
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        // Overload the equality operator to compare Employee objects by ID
        public static bool operator ==(Employee emp1, Employee emp2)
        {
            // Check if both objects are null or reference the same object
            if (ReferenceEquals(emp1, emp2))
                return true;

            // Check if either is null
            if ((object)emp1 == null || (object)emp2 == null)
                return false;

            // Compare ID property for equality
            return emp1.ID == emp2.ID;
        }

        // Overload the inequality operator
        public static bool operator !=(Employee emp1, Employee emp2)
        {
            return !(emp1 == emp2);
        }

        // Override Equals and GetHashCode (recommended when overloading == and !=)
        public override bool Equals(object obj)
        {
            if (obj is Employee emp)
                return this.ID == emp.ID;
            return false;
        }

        public override int GetHashCode()
        {
            return this.ID.GetHashCode();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Instantiate the first Employee object
            Employee emp1 = new Employee()
            {
                ID = 101,
                FirstName = "John",
                LastName = "Doe"
            };

            // Instantiate the second Employee object
            Employee emp2 = new Employee()
            {
                ID = 101,
                FirstName = "Jane",
                LastName = "Smith"
            };

            // Compare the two Employee objects using the overloaded == operator
            bool areEqual = emp1 == emp2;

            // Display the result of the comparison
            Console.WriteLine("Are the two employees equal? " + areEqual);

            // Keep the console window open
            Console.ReadLine();
        }
    }
}
